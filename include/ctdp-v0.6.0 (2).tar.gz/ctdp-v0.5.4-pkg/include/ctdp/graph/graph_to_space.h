// graph/graph_to_space.h — FORWARDING SHIM
// Canonical location: engine/bridge/graph_to_space.h
//
// graph_to_space bridges the Graph tier to the DP Solver tier.
// It belongs in engine/bridge/ (not graph/) because it depends
// upward on solver-level abstractions (schedule spaces).
//
// This shim preserves backward compatibility for existing code
// that includes from the graph/ directory.

#ifndef CTDP_GRAPH_TO_SPACE_SHIM_H
#define CTDP_GRAPH_TO_SPACE_SHIM_H

#include "../engine/bridge/graph_to_space.h"

#endif // CTDP_GRAPH_TO_SPACE_SHIM_H
