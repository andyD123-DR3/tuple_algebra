// graph/graph_to_constraints.h — FORWARDING SHIM
// Canonical location: engine/bridge/graph_to_constraints.h
//
// graph_to_constraints bridges the Graph tier to the DP Solver tier.
// It belongs in engine/bridge/ (not graph/) because it depends
// on graph_to_space (another engine/bridge component).
//
// This shim preserves backward compatibility for existing code
// that includes from the graph/ directory.

#ifndef CTDP_GRAPH_TO_CONSTRAINTS_SHIM_H
#define CTDP_GRAPH_TO_CONSTRAINTS_SHIM_H

#include "../engine/bridge/graph_to_constraints.h"

#endif // CTDP_GRAPH_TO_CONSTRAINTS_SHIM_H
